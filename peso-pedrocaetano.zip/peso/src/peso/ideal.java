/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package peso;
import java.util.Scanner;
/**
 *
 * @azuthor pedro
 */
public class ideal {

 public static void main(String[] args) {
        Scanner ler = new Scanner (System.in);
        System.out.println("Digite seu nome: ");
        String nome = ler.nextLine();
        
        System.out.println("Digite sua idade: ");
        int idade = ler.nextInt();
        
        System.out.println("Digite sua altura: ");
        double altura = ler.nextDouble();
        
        System.out.println("Digite seu peso:  ");
        double peso = ler.nextDouble();
        
        double pesoideal = altura-100;
        
        if (pesoideal==peso){
            System.out.println("Seu nome é" + nome + "voce tem" + idade +
                    "anos ,peso "+peso+"kilos e tem "+altura+" de altura e está em seu peso ideal");
        }else if (pesoideal>peso){
            System.out.println("Seu nome é" + nome + "voce tem " + idade + "anos, peso " + peso + "kilos e tem "
                    +altura+"de altura e voce deve emagrecer " + (pesoideal-peso) + "para entrar em seu peso ideal." ); 
            
        }
    else{
    System.out.println("Seu nome é" + nome + "voce tem " + idade + 
            "anos, peso " + peso + "kilos e tem "
                    +altura+
            "de altura e voce deve emagrecer " + (peso-pesoideal) + "para entrar em seu peso ideal." );                        
                       
        }
}
}

  
    
    

